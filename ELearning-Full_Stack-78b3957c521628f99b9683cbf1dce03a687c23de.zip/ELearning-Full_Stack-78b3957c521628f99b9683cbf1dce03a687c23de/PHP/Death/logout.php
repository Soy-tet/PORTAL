<?php 
setcookie("username","",time()-237499);
?>